package computerbuild;


public class Date_Cpu extends brand_cpu{
    
 private String date_CPU;

 public String getdate_CPU(){
return date_CPU;
}
 public void setdate_CPU(String date_data){
   date_CPU=date_data;
   }
  void code(){
     System.out.println("new date code is : 2021");
 }
  
}