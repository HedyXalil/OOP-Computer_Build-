package computerbuild;

public interface order{
public void name(String a);
public void ramup(int a);
public void ramdown(int a);
 public void print();


}