
package computerbuild;

public class New_cpu extends brand_cpu{
 String new_CPU;
       public String getnew_CPU(){
return new_CPU;
}
   public void setnew_CPU(String new_data){
   new_CPU=new_data;
   } 
  void code(){
     System.out.println("new cpu code is : 4532");
 }
}  